package com.limpio.browser

import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat

/** Pantalla de ajustes. Guarda en Ajustes; MainActivity los aplica al volver. */
class AjustesActivity : AppCompatActivity() {

    private lateinit var contenido: LinearLayout

    private val ink by lazy { ContextCompat.getColor(this, R.color.ink) }
    private val muted by lazy { ContextCompat.getColor(this, R.color.icon_muted) }
    private val linea by lazy { ContextCompat.getColor(this, R.color.line) }
    private val marca by lazy { ContextCompat.getColor(this, R.color.brand) }
    private val fondo by lazy { ContextCompat.getColor(this, R.color.surface) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        contenido = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(32))
        }
        val scroll = ScrollView(this).apply { addView(contenido) }

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(fondo)
            addView(cabecera())
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(raiz)
        construir()
    }

    private fun cabecera(): View {
        val fila = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(16), 0)
        }
        val atras = ImageButton(this).apply {
            setImageResource(R.drawable.ic_back)
            imageTintList = ColorStateList.valueOf(ink)
            contentDescription = getString(R.string.cd_back)
            val tv = android.util.TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            setOnClickListener { finish() }
        }
        fila.addView(atras, LinearLayout.LayoutParams(dp(48), dp(56)))
        fila.addView(
            TextView(this).apply {
                text = "Ajustes"
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(ink)
            }
        )
        return fila
    }

    private fun construir() {
        contenido.removeAllViews()

        seccion("Búsqueda")
        filaSelector("Motor de búsqueda", Ajustes.motor(this).nombre) {
            val nombres = Ajustes.motores.map { it.nombre }.toTypedArray()
            val actual = Ajustes.motores.indexOfFirst { it.id == Ajustes.motor(this).id }
            elegir("Motor de búsqueda", nombres, actual) { i ->
                Ajustes.setMotor(this, Ajustes.motores[i].id)
            }
        }

        seccion("Privacidad y seguridad")
        filaSwitch(
            "Bloquear anuncios",
            "Usa uBlock Origin para bloquear anuncios y rastreadores en páginas y videos. " +
                "La primera vez se descarga, necesita internet.",
            Ajustes.anuncios(this)
        ) { Ajustes.setAnuncios(this, it) }
        filaSelector("Protección contra rastreadores", Ajustes.rastreoNombres[Ajustes.rastreo(this)]) {
            elegir(
                "Protección contra rastreadores",
                Ajustes.rastreoNombres.toTypedArray(),
                Ajustes.rastreo(this)
            ) { i -> Ajustes.setRastreo(this, i) }
        }
        filaSelector("Cookies", Ajustes.cookiesNombres[Ajustes.cookiesIndice(this)]) {
            elegir(
                "Cookies",
                Ajustes.cookiesNombres.toTypedArray(),
                Ajustes.cookiesIndice(this)
            ) { i -> Ajustes.setCookiesIndice(this, i) }
        }
        filaSwitch(
            "Conectarse solo por HTTPS",
            "Evita abrir sitios sin cifrado. Algunos sitios antiguos no cargarán.",
            Ajustes.soloHttps(this)
        ) { Ajustes.setSoloHttps(this, it) }
        filaSwitch(
            "Global Privacy Control",
            "Pide a los sitios que no vendan ni compartan tus datos.",
            Ajustes.gpc(this)
        ) { Ajustes.setGpc(this, it) }
        filaSwitch(
            "Permitir capturas en incógnito",
            "Si está apagado, las pestañas de incógnito no se pueden capturar ni se ven en recientes.",
            Ajustes.capturasIncognito(this)
        ) { Ajustes.setCapturasIncognito(this, it) }
        filaSwitch(
            "Borrar datos al salir",
            "Borra cookies, caché y datos de sitios cuando cierras Limpio.",
            Ajustes.borrarAlSalir(this)
        ) { Ajustes.setBorrarAlSalir(this, it) }
        filaAccion("Borrar datos de navegación ahora", "Cookies, caché y datos de sitios") {
            AlertDialog.Builder(this)
                .setTitle("Borrar datos de navegación")
                .setMessage("Se cerrarán tus sesiones en los sitios. ¿Continuar?")
                .setPositiveButton("Borrar") { _, _ ->
                    Ajustes.pedirBorrado(this)
                    Toast.makeText(this, "Se borrarán al volver al navegador", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        seccion("Apariencia")
        filaSelector("Tema", Ajustes.temaNombres[Ajustes.tema(this)]) {
            elegir("Tema", Ajustes.temaNombres.toTypedArray(), Ajustes.tema(this)) { i ->
                Ajustes.setTema(this, i)
                AppCompatDelegate.setDefaultNightMode(Ajustes.modoNoche(this))
            }
        }
        filaSelector("Tamaño del texto", Ajustes.textoNombres[Ajustes.textoIndice(this)]) {
            elegir(
                "Tamaño del texto",
                Ajustes.textoNombres.toTypedArray(),
                Ajustes.textoIndice(this)
            ) { i -> Ajustes.setTextoIndice(this, i) }
        }

        seccion("Navegación")
        filaSwitch(
            "Sitio de escritorio por defecto",
            "Las pestañas nuevas piden la versión de escritorio. También puedes cambiarlo por " +
                "pestaña desde el menú.",
            Ajustes.escritorioPorDefecto(this)
        ) { Ajustes.setEscritorioPorDefecto(this, it) }

        seccion("Acerca de")
        filaInfo("Limpio 1.0.0", "Motor GeckoView (Firefox)")
    }

    // ---------- Piezas de interfaz ----------

    private fun seccion(titulo: String) {
        contenido.addView(
            TextView(this).apply {
                text = titulo
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(marca)
                setPadding(dp(20), dp(24), dp(20), dp(6))
            }
        )
    }

    private fun filaBase(titulo: String, sub: String?): Pair<LinearLayout, LinearLayout> {
        val fila = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            minimumHeight = dp(56)
            val tv = android.util.TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            setBackgroundResource(tv.resourceId)
        }
        val textos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textos.addView(
            TextView(this).apply {
                text = titulo
                textSize = 16f
                setTextColor(ink)
            }
        )
        if (!sub.isNullOrEmpty()) {
            textos.addView(
                TextView(this).apply {
                    text = sub
                    textSize = 13f
                    setTextColor(muted)
                    setPadding(0, dp(2), 0, 0)
                }
            )
        }
        fila.addView(textos, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        contenido.addView(fila)
        return Pair(fila, textos)
    }

    private fun filaSelector(titulo: String, valor: String, alTocar: () -> Unit) {
        val (fila, _) = filaBase(titulo, valor)
        fila.setOnClickListener { alTocar() }
    }

    private fun filaAccion(titulo: String, sub: String, alTocar: () -> Unit) {
        val (fila, _) = filaBase(titulo, sub)
        fila.setOnClickListener { alTocar() }
    }

    private fun filaInfo(titulo: String, sub: String) {
        filaBase(titulo, sub)
    }

    private fun filaSwitch(titulo: String, sub: String, valor: Boolean, alCambiar: (Boolean) -> Unit) {
        val (fila, _) = filaBase(titulo, sub)
        val sw = SwitchCompat(this).apply {
            isChecked = valor
            thumbTintList = ColorStateList.valueOf(marca)
            trackTintList = ColorStateList.valueOf(linea)
            setOnCheckedChangeListener { _, marcado -> alCambiar(marcado) }
        }
        fila.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(12)
        })
        fila.setOnClickListener { sw.toggle() }
    }

    private fun elegir(titulo: String, opciones: Array<String>, seleccionada: Int, alElegir: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setSingleChoiceItems(opciones, seleccionada) { dialogo, cual ->
                alElegir(cual)
                dialogo.dismiss()
                construir()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
