package com.limpio.browser

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntimeSettings

data class Motor(val id: String, val nombre: String, val url: String)
data class Favorito(val titulo: String, val url: String)

/** Todos los ajustes de Limpio viven aquí (SharedPreferences). */
object Ajustes {

    private const val PREFS = "limpio"

    val motores = listOf(
        Motor("google", "Google", "https://www.google.com/search?q="),
        Motor("ddg", "DuckDuckGo", "https://duckduckgo.com/?q="),
        Motor("brave", "Brave Search", "https://search.brave.com/search?q="),
        Motor("bing", "Bing", "https://www.bing.com/search?q="),
        Motor("ecosia", "Ecosia", "https://www.ecosia.org/search?q="),
        Motor("startpage", "Startpage", "https://www.startpage.com/do/search?q=")
    )

    val rastreoNombres = listOf("Desactivada", "Estándar", "Estricta")

    val cookiesNombres = listOf(
        "Bloquear rastreadores (recomendado)",
        "Aislar cookies de terceros",
        "Bloquear cookies de terceros",
        "Bloquear todas las cookies",
        "Permitir todas"
    )

    private val cookiesValores = intArrayOf(
        ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS,
        ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS,
        ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY,
        ContentBlocking.CookieBehavior.ACCEPT_NONE,
        ContentBlocking.CookieBehavior.ACCEPT_ALL
    )

    val temaNombres = listOf("Según el sistema", "Claro", "Oscuro")
    val textoNombres = listOf("Pequeño", "Normal", "Grande", "Muy grande")
    private val textoFactores = floatArrayOf(0.85f, 1.0f, 1.15f, 1.3f)

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- Búsqueda ----------

    fun motor(c: Context): Motor {
        val id = p(c).getString("motor", "google")
        return motores.firstOrNull { it.id == id } ?: motores[0]
    }

    fun setMotor(c: Context, id: String) = p(c).edit().putString("motor", id).apply()

    // ---------- Privacidad ----------

    fun anuncios(c: Context) = p(c).getBoolean("anuncios", true)
    fun setAnuncios(c: Context, v: Boolean) = p(c).edit().putBoolean("anuncios", v).apply()

    /** 0 = desactivada, 1 = estándar, 2 = estricta */
    fun rastreo(c: Context) = p(c).getInt("rastreo", 2).coerceIn(0, 2)
    fun setRastreo(c: Context, v: Int) = p(c).edit().putInt("rastreo", v).apply()

    fun cookiesIndice(c: Context) = p(c).getInt("cookies", 0).coerceIn(0, cookiesValores.size - 1)
    fun setCookiesIndice(c: Context, v: Int) = p(c).edit().putInt("cookies", v).apply()
    fun cookiesValor(c: Context) = cookiesValores[cookiesIndice(c)]

    fun soloHttps(c: Context) = p(c).getBoolean("https", true)
    fun setSoloHttps(c: Context, v: Boolean) = p(c).edit().putBoolean("https", v).apply()

    fun gpc(c: Context) = p(c).getBoolean("gpc", true)
    fun setGpc(c: Context, v: Boolean) = p(c).edit().putBoolean("gpc", v).apply()

    fun capturasIncognito(c: Context) = p(c).getBoolean("capturas_incognito", false)
    fun setCapturasIncognito(c: Context, v: Boolean) =
        p(c).edit().putBoolean("capturas_incognito", v).apply()

    fun borrarAlSalir(c: Context) = p(c).getBoolean("borrar_salir", false)
    fun setBorrarAlSalir(c: Context, v: Boolean) = p(c).edit().putBoolean("borrar_salir", v).apply()

    /** El botón del escudo enciende o apaga anuncios y rastreadores juntos. */
    fun proteccionActiva(c: Context) = anuncios(c) || rastreo(c) != 0

    fun setProteccion(c: Context, activa: Boolean) {
        p(c).edit()
            .putBoolean("anuncios", activa)
            .putInt("rastreo", if (activa) 2 else 0)
            .apply()
    }

    // Borrado pedido desde Ajustes; MainActivity lo ejecuta al volver.
    fun pedirBorrado(c: Context) = p(c).edit().putBoolean("borrar_pendiente", true).apply()

    fun consumirBorrado(c: Context): Boolean {
        val pendiente = p(c).getBoolean("borrar_pendiente", false)
        if (pendiente) p(c).edit().putBoolean("borrar_pendiente", false).apply()
        return pendiente
    }

    // ---------- Apariencia ----------

    fun tema(c: Context) = p(c).getInt("tema", 0).coerceIn(0, 2)
    fun setTema(c: Context, v: Int) = p(c).edit().putInt("tema", v).apply()

    fun modoNoche(c: Context): Int = when (tema(c)) {
        1 -> AppCompatDelegate.MODE_NIGHT_NO
        2 -> AppCompatDelegate.MODE_NIGHT_YES
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    fun esquemaGecko(c: Context): Int = when (tema(c)) {
        1 -> GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
        2 -> GeckoRuntimeSettings.COLOR_SCHEME_DARK
        else -> GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
    }

    fun textoIndice(c: Context) = p(c).getInt("texto", 1).coerceIn(0, textoFactores.size - 1)
    fun setTextoIndice(c: Context, v: Int) = p(c).edit().putInt("texto", v).apply()
    fun textoFactor(c: Context) = textoFactores[textoIndice(c)]

    // ---------- Navegación ----------

    fun escritorioPorDefecto(c: Context) = p(c).getBoolean("escritorio", false)
    fun setEscritorioPorDefecto(c: Context, v: Boolean) =
        p(c).edit().putBoolean("escritorio", v).apply()

    // ---------- Favoritos ----------

    private fun favoritosIniciales() = mutableListOf(
        Favorito("YouTube", "https://m.youtube.com"),
        Favorito("Wikipedia", "https://es.wikipedia.org"),
        Favorito("Maps", "https://www.google.com/maps")
    )

    fun favoritos(c: Context): MutableList<Favorito> {
        val crudo = p(c).getString("favoritos", null)
        if (crudo == null) {
            val inicial = favoritosIniciales()
            guardarFavoritos(c, inicial)
            return inicial
        }
        return try {
            val a = JSONArray(crudo)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                Favorito(o.getString("t"), o.getString("u"))
            }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun guardarFavoritos(c: Context, lista: List<Favorito>) {
        val a = JSONArray()
        for (f in lista) a.put(JSONObject().put("t", f.titulo).put("u", f.url))
        p(c).edit().putString("favoritos", a.toString()).apply()
    }
}
