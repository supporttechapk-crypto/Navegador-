package com.limpio.browser

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.URLUtil
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import org.mozilla.geckoview.WebResponse
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private class Pestana(val privada: Boolean, val session: GeckoSession) {
        var url: String = ""
        var titulo: String = ""
        var puedeAtras = false
        var puedeAdelante = false
        var cargando = false
        var inicio = true
    }

    private class Paleta(
        val surface: Int,
        val field: Int,
        val ink: Int,
        val muted: Int,
        val line: Int,
        val brand: Int
    )

    private lateinit var rt: GeckoRuntime

    private lateinit var raiz: FrameLayout
    private lateinit var principal: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var bottomLine: View
    private lateinit var geckoView: GeckoView
    private lateinit var inicioView: ScrollView
    private lateinit var inicioContenido: LinearLayout
    private lateinit var urlField: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnShield: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var btnTabs: FrameLayout
    private lateinit var tabsConteo: TextView

    private lateinit var tabsOverlay: LinearLayout
    private lateinit var tabsTitulo: TextView
    private lateinit var tabsListo: TextView
    private lateinit var segNormal: TextView
    private lateinit var segPrivada: TextView
    private lateinit var tabsList: ListView
    private lateinit var tabsCerrarTodas: TextView
    private lateinit var tabsNueva: TextView

    private val pestanas = mutableListOf<Pestana>()
    private var actual: Pestana? = null
    private var verPrivadas = false
    private var pantallaCompleta = false
    private var saltarPrimerResume = true
    private var instalandoUbo = false

    // ---------- Ciclo de vida ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enlazarVistas()

        rt = obtenerRuntime()
        configurarExtensiones()
        configurarControles()
        configurarSelectorDePestanas()
        aplicarAjustes()

        val inicial = intent?.data?.toString()
        nuevaPestana(false, if (inicial.isNullOrBlank()) null else inicial)
    }

    override fun onResume() {
        super.onResume()
        if (saltarPrimerResume) {
            saltarPrimerResume = false
            return
        }
        if (Ajustes.consumirBorrado(this)) borrarDatos()
        aplicarAjustes()
        aplicarColores()
        renderInicio()
        actualizarUI()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val destino = intent.data?.toString()
        if (!destino.isNullOrBlank()) nuevaPestana(false, destino)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        aplicarColores()
        renderInicio()
        actualizarUI()
        if (tabsOverlay.visibility == View.VISIBLE) renderPestanas()
    }

    override fun onDestroy() {
        geckoView.releaseSession()
        for (p in pestanas) p.session.close()
        pestanas.clear()
        if (isFinishing && Ajustes.borrarAlSalir(this)) {
            rt.storageController.clearData(StorageController.ClearFlags.ALL)
        }
        super.onDestroy()
    }

    // ---------- Motor, privacidad y ajustes ----------

    private fun obtenerRuntime(): GeckoRuntime {
        val existente = runtime
        if (existente != null) return existente
        val ajustes = GeckoRuntimeSettings.Builder()
            .allowInsecureConnections(
                if (Ajustes.soloHttps(this)) GeckoRuntimeSettings.HTTPS_ONLY
                else GeckoRuntimeSettings.ALLOW_ALL
            )
            .remoteDebuggingEnabled(false)
            .build()
        val nuevo = GeckoRuntime.create(applicationContext, ajustes)
        runtime = nuevo
        return nuevo
    }

    /** Lee todos los ajustes y los aplica al motor. Se llama al iniciar y al volver de Ajustes. */
    private fun aplicarAjustes() {
        val s = rt.settings

        s.setAllowInsecureConnections(
            if (Ajustes.soloHttps(this)) GeckoRuntimeSettings.HTTPS_ONLY
            else GeckoRuntimeSettings.ALLOW_ALL
        )
        s.setGlobalPrivacyControl(Ajustes.gpc(this))
        s.setPreferredColorScheme(Ajustes.esquemaGecko(this))

        // Primero se apaga el ajuste automático; si no, setFontSizeFactor lanza excepción.
        s.setAutomaticFontSizeAdjustment(false)
        s.setFontSizeFactor(Ajustes.textoFactor(this))

        val bloqueo = s.contentBlocking
        when (Ajustes.rastreo(this)) {
            0 -> {
                bloqueo.setAntiTracking(ContentBlocking.AntiTracking.NONE)
                bloqueo.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.NONE)
            }
            1 -> {
                bloqueo.setAntiTracking(ContentBlocking.AntiTracking.DEFAULT)
                bloqueo.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.DEFAULT)
            }
            else -> {
                bloqueo.setAntiTracking(ContentBlocking.AntiTracking.STRICT)
                bloqueo.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
            }
        }
        bloqueo.setCookieBehavior(Ajustes.cookiesValor(this))
        bloqueo.setCookieBehaviorPrivateMode(Ajustes.cookiesValor(this))

        AppCompatDelegate.setDefaultNightMode(Ajustes.modoNoche(this))

        configurarAnuncios()
    }

    // ---------- Bloqueador de anuncios (uBlock Origin) ----------

    private fun configurarExtensiones() {
        rt.webExtensionController.promptDelegate = object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>,
                dataCollectionPermissions: Array<String>
            ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                // Solo se instala uBlock Origin, que lo pide el propio navegador.
                return GeckoResult.fromValue(WebExtension.PermissionPromptResponse(true, true, false))
            }
        }
    }

    private fun configurarAnuncios() {
        val quiere = Ajustes.anuncios(this)
        rt.webExtensionController.list().accept({ lista ->
            val ubo = lista?.firstOrNull { it.id == UBO_ID }
            if (ubo == null) {
                if (quiere) instalarUbo()
            } else {
                sincronizarUbo(ubo, quiere)
            }
        }, { _ -> })
    }

    private fun instalarUbo() {
        if (instalandoUbo) return
        instalandoUbo = true
        val ctl = rt.webExtensionController
        ctl.install(UBO_URL, WebExtensionController.INSTALLATION_METHOD_MANAGER).accept({ ext ->
            instalandoUbo = false
            if (ext != null) {
                ctl.setAllowedInPrivateBrowsing(ext, true)
                Toast.makeText(this, "Bloqueador de anuncios activado", Toast.LENGTH_SHORT).show()
            }
        }, { _ ->
            instalandoUbo = false
            Toast.makeText(
                this,
                "No se pudo instalar el bloqueador de anuncios. Revisa tu internet; se reintentará.",
                Toast.LENGTH_LONG
            ).show()
        })
    }

    private fun sincronizarUbo(ubo: WebExtension, quiere: Boolean) {
        val ctl = rt.webExtensionController
        if (quiere && !ubo.metaData.enabled) {
            ctl.enable(ubo, WebExtensionController.EnableSource.USER)
        } else if (!quiere && ubo.metaData.enabled) {
            ctl.disable(ubo, WebExtensionController.EnableSource.USER)
        }
        if (quiere && !ubo.metaData.allowedInPrivateBrowsing) {
            ctl.setAllowedInPrivateBrowsing(ubo, true)
        }
    }

    // ---------- Pestañas ----------

    private fun nuevaPestana(privada: Boolean, url: String?): Pestana {
        val escritorio = Ajustes.escritorioPorDefecto(this)
        val ajustes = GeckoSessionSettings.Builder()
            .usePrivateMode(privada)
            .userAgentMode(
                if (escritorio) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
            )
            .viewportMode(
                if (escritorio) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
            )
            .build()

        val sesion = GeckoSession(ajustes)
        val p = Pestana(privada, sesion)
        sesion.progressDelegate = crearProgressDelegate(p)
        sesion.navigationDelegate = crearNavigationDelegate(p)
        sesion.contentDelegate = crearContentDelegate(p)
        sesion.open(rt)

        pestanas.add(p)
        seleccionar(p)
        if (url != null) cargar(url)
        return p
    }

    private fun seleccionar(p: Pestana) {
        actual = p
        for (o in pestanas) if (o !== p) o.session.setActive(false)
        geckoView.setSession(p.session)
        p.session.setActive(true)
        ocultarPestanas()
        if (pantallaCompleta) modoPantallaCompleta(false)
        if (p.privada && !Ajustes.capturasIncognito(this)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        aplicarColores()
        renderInicio()
        actualizarUI()
    }

    private fun cerrarPestana(p: Pestana) {
        val idx = pestanas.indexOf(p)
        if (idx < 0) return
        pestanas.removeAt(idx)
        val eraActual = actual === p
        if (eraActual) {
            actual = null
            geckoView.releaseSession()
        }
        p.session.close()

        if (pestanas.isEmpty()) {
            nuevaPestana(false, null)
        } else if (eraActual) {
            seleccionar(pestanas[min(idx, pestanas.size - 1)])
        } else {
            actualizarUI()
        }
        if (tabsOverlay.visibility == View.VISIBLE) renderPestanas()
    }

    private fun visibles(): List<Pestana> = pestanas.filter { it.privada == verPrivadas }

    private val adaptadorPestanas = object : BaseAdapter() {
        override fun getCount(): Int = visibles().size
        override fun getItem(position: Int): Any = visibles()[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView
                ?: LayoutInflater.from(this@MainActivity).inflate(R.layout.item_tab, parent, false)
            val p = visibles()[position]
            val pal = paleta(verPrivadas)

            val tarjeta = v.findViewById<LinearLayout>(R.id.tabTarjeta)
            tarjeta.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(pal.field)
                if (p === actual) setStroke(dp(2), pal.brand)
            }
            val titulo = v.findViewById<TextView>(R.id.tabTitulo)
            val url = v.findViewById<TextView>(R.id.tabUrl)
            titulo.text = when {
                p.titulo.isNotBlank() -> p.titulo
                p.inicio || p.url.isEmpty() -> "Nueva pestaña"
                else -> legible(p.url)
            }
            url.text = if (p.url.isEmpty()) "Página de inicio" else legible(p.url)
            titulo.setTextColor(pal.ink)
            url.setTextColor(pal.muted)

            val cerrar = v.findViewById<ImageButton>(R.id.tabCerrar)
            cerrar.imageTintList = ColorStateList.valueOf(pal.muted)
            cerrar.setOnClickListener { cerrarPestana(p) }
            return v
        }
    }

    private fun configurarSelectorDePestanas() {
        tabsList.adapter = adaptadorPestanas
        tabsList.setOnItemClickListener { _, _, position, _ ->
            visibles().getOrNull(position)?.let { seleccionar(it) }
        }
        tabsListo.setOnClickListener { ocultarPestanas() }
        segNormal.setOnClickListener { verPrivadas = false; renderPestanas() }
        segPrivada.setOnClickListener { verPrivadas = true; renderPestanas() }
        tabsNueva.setOnClickListener { nuevaPestana(verPrivadas, null) }
        tabsCerrarTodas.setOnClickListener {
            for (p in visibles().toList()) cerrarPestana(p)
        }
    }

    private fun mostrarPestanas() {
        verPrivadas = actual?.privada == true
        tabsOverlay.visibility = View.VISIBLE
        renderPestanas()
        ocultarTeclado()
    }

    private fun ocultarPestanas() {
        tabsOverlay.visibility = View.GONE
    }

    private fun renderPestanas() {
        val pal = paleta(verPrivadas)
        tabsOverlay.setBackgroundColor(pal.surface)
        tabsTitulo.setTextColor(pal.ink)
        tabsListo.setTextColor(pal.brand)
        tabsCerrarTodas.setTextColor(pal.muted)
        tabsNueva.setTextColor(pal.brand)

        val normales = pestanas.count { !it.privada }
        val privadas = pestanas.count { it.privada }
        segNormal.text = "Pestañas ($normales)"
        segPrivada.text = "Incógnito ($privadas)"
        estiloSegmento(segNormal, !verPrivadas, pal)
        estiloSegmento(segPrivada, verPrivadas, pal)
        tabsTitulo.text = if (verPrivadas) "Pestañas de incógnito" else "Pestañas"
        adaptadorPestanas.notifyDataSetChanged()
    }

    private fun estiloSegmento(t: TextView, activo: Boolean, pal: Paleta) {
        t.setTextColor(if (activo) pal.ink else pal.muted)
        t.typeface = if (activo) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        t.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (activo) pal.field else Color.TRANSPARENT)
        }
    }

    // ---------- Delegados de la sesión ----------

    private fun crearProgressDelegate(p: Pestana) = object : GeckoSession.ProgressDelegate {
        override fun onPageStart(s: GeckoSession, url: String) {
            p.cargando = true
            if (p === actual) {
                progressBar.progress = 0
                actualizarUI()
            }
        }

        override fun onPageStop(s: GeckoSession, success: Boolean) {
            p.cargando = false
            if (p === actual) actualizarUI()
        }

        override fun onProgressChange(s: GeckoSession, progress: Int) {
            if (p === actual) progressBar.progress = progress
        }
    }

    private fun crearNavigationDelegate(p: Pestana) = object : GeckoSession.NavigationDelegate {
        override fun onLocationChange(
            s: GeckoSession,
            url: String?,
            perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
            hasUserGesture: Boolean
        ) {
            if (url == null || url == "about:blank") return
            p.url = url
            p.inicio = false
            if (p === actual) actualizarUI()
        }

        override fun onCanGoBack(s: GeckoSession, canGoBack: Boolean) {
            p.puedeAtras = canGoBack
            if (p === actual) actualizarUI()
        }

        override fun onCanGoForward(s: GeckoSession, canGoForward: Boolean) {
            p.puedeAdelante = canGoForward
            if (p === actual) actualizarUI()
        }

        override fun onLoadRequest(
            s: GeckoSession,
            request: GeckoSession.NavigationDelegate.LoadRequest
        ): GeckoResult<AllowOrDeny>? {
            val destino = request.uri
            val externo = destino.startsWith("mailto:") || destino.startsWith("tel:") ||
                destino.startsWith("sms:") || destino.startsWith("geo:")
            if (externo) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(destino)))
                } catch (e: ActivityNotFoundException) {
                    // No hay una aplicación que lo abra.
                }
                return GeckoResult.fromValue(AllowOrDeny.DENY)
            }
            return null
        }

        override fun onNewSession(s: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
            // Los enlaces que piden una ventana nueva se abren en la misma pestaña.
            p.session.loadUri(uri)
            return null
        }
    }

    private fun crearContentDelegate(p: Pestana) = object : GeckoSession.ContentDelegate {
        override fun onTitleChange(session: GeckoSession, title: String?) {
            p.titulo = title ?: ""
            if (tabsOverlay.visibility == View.VISIBLE) adaptadorPestanas.notifyDataSetChanged()
        }

        override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
            if (p === actual) modoPantallaCompleta(fullScreen)
        }

        override fun onCloseRequest(session: GeckoSession) {
            cerrarPestana(p)
        }

        override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
            descargar(response)
        }

        override fun onCrash(session: GeckoSession) {
            recuperar(p)
        }

        override fun onKill(session: GeckoSession) {
            recuperar(p)
        }
    }

    private fun recuperar(p: Pestana) {
        p.session.open(rt)
        if (p === actual) geckoView.setSession(p.session)
        if (p.url.isNotEmpty() && !p.inicio) p.session.loadUri(p.url)
    }

    // ---------- Controles ----------

    private fun enlazarVistas() {
        raiz = findViewById(R.id.raiz)
        principal = findViewById(R.id.principal)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        bottomLine = findViewById(R.id.bottomLine)
        geckoView = findViewById(R.id.geckoView)
        inicioView = findViewById(R.id.inicioView)
        inicioContenido = findViewById(R.id.inicioContenido)
        urlField = findViewById(R.id.urlField)
        progressBar = findViewById(R.id.progressBar)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnReload = findViewById(R.id.btnReload)
        btnHome = findViewById(R.id.btnHome)
        btnShield = findViewById(R.id.btnShield)
        btnMenu = findViewById(R.id.btnMenu)
        btnTabs = findViewById(R.id.btnTabs)
        tabsConteo = findViewById(R.id.tabsConteo)
        tabsOverlay = findViewById(R.id.tabsOverlay)
        tabsTitulo = findViewById(R.id.tabsTitulo)
        tabsListo = findViewById(R.id.tabsListo)
        segNormal = findViewById(R.id.segNormal)
        segPrivada = findViewById(R.id.segPrivada)
        tabsList = findViewById(R.id.tabsList)
        tabsCerrarTodas = findViewById(R.id.tabsCerrarTodas)
        tabsNueva = findViewById(R.id.tabsNueva)
    }

    private fun configurarControles() {
        urlField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                cargar(urlField.text.toString())
                ocultarTeclado()
                true
            } else {
                false
            }
        }
        urlField.setOnFocusChangeListener { _, tieneFoco ->
            val p = actual
            if (tieneFoco) {
                urlField.setText(if (p == null || p.inicio) "" else p.url)
                urlField.post { urlField.selectAll() }
            } else {
                urlField.setText(if (p == null || p.inicio) "" else legible(p.url))
            }
        }

        btnBack.setOnClickListener { retroceder() }
        btnForward.setOnClickListener {
            val p = actual ?: return@setOnClickListener
            if (p.puedeAdelante) p.session.goForward()
        }
        btnReload.setOnClickListener {
            val p = actual ?: return@setOnClickListener
            if (p.inicio) return@setOnClickListener
            if (p.cargando) p.session.stop() else p.session.reload()
        }
        btnHome.setOnClickListener { mostrarInicio() }
        btnTabs.setOnClickListener { mostrarPestanas() }

        btnShield.setOnClickListener {
            val activar = !Ajustes.proteccionActiva(this)
            Ajustes.setProteccion(this, activar)
            aplicarAjustes()
            actualizarUI()
            actual?.let { if (!it.inicio) it.session.reload() }
            Toast.makeText(
                this,
                if (activar) R.string.proteccion_on else R.string.proteccion_off,
                Toast.LENGTH_SHORT
            ).show()
        }

        btnMenu.setOnClickListener { mostrarMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (tabsOverlay.visibility == View.VISIBLE) {
                    ocultarPestanas()
                    return
                }
                if (retroceder()) return
                val p = actual
                if (p != null && (pestanas.size > 1 || p.privada)) {
                    cerrarPestana(p)
                } else {
                    finish()
                }
            }
        })
    }

    /** Devuelve true si el atrás se resolvió dentro de la pestaña actual. */
    private fun retroceder(): Boolean {
        val p = actual ?: return false
        if (pantallaCompleta) {
            p.session.exitFullScreen()
            return true
        }
        if (p.inicio && p.url.isNotEmpty()) {
            p.inicio = false
            actualizarUI()
            return true
        }
        if (p.puedeAtras) {
            p.session.goBack()
            return true
        }
        return false
    }

    private fun mostrarInicio() {
        val p = actual ?: return
        p.inicio = true
        renderInicio()
        actualizarUI()
        urlField.clearFocus()
        ocultarTeclado()
    }

    private fun mostrarMenu() {
        val p = actual ?: return
        val menu = PopupMenu(this, btnMenu)
        menu.menu.add(0, MENU_NUEVA, 0, "Nueva pestaña")
        menu.menu.add(0, MENU_INCOGNITO, 1, "Nueva pestaña de incógnito")
        val esFav = !p.inicio && p.url.isNotEmpty() && Ajustes.favoritos(this).any { it.url == p.url }
        menu.menu.add(0, MENU_FAVORITO, 2, if (esFav) "Quitar de favoritos" else "Añadir a favoritos")
        val escritorio = p.session.settings.userAgentMode == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        val itemEscritorio = menu.menu.add(0, MENU_ESCRITORIO, 3, "Sitio de escritorio")
        itemEscritorio.isCheckable = true
        itemEscritorio.isChecked = escritorio
        menu.menu.add(0, MENU_COMPARTIR, 4, "Compartir página")
        menu.menu.add(0, MENU_DESCARGAS, 5, "Descargas")
        menu.menu.add(0, MENU_AJUSTES, 6, "Ajustes")
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                MENU_NUEVA -> nuevaPestana(false, null)
                MENU_INCOGNITO -> nuevaPestana(true, null)
                MENU_FAVORITO -> alternarFavorito(p)
                MENU_ESCRITORIO -> alternarEscritorio(p)
                MENU_COMPARTIR -> compartir(p)
                MENU_DESCARGAS -> abrirDescargas()
                MENU_AJUSTES -> startActivity(Intent(this, AjustesActivity::class.java))
            }
            true
        }
        menu.show()
    }

    private fun alternarEscritorio(p: Pestana) {
        val st = p.session.settings
        val activar = st.userAgentMode != GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        st.setUserAgentMode(
            if (activar) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
            else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        )
        st.setViewportMode(
            if (activar) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
            else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        )
        if (!p.inicio) p.session.reload(GeckoSession.LOAD_FLAGS_BYPASS_CACHE)
        Toast.makeText(
            this,
            if (activar) "Sitio de escritorio activado" else "Sitio móvil activado",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun alternarFavorito(p: Pestana) {
        if (p.inicio || p.url.isEmpty()) {
            Toast.makeText(this, "Abre una página primero", Toast.LENGTH_SHORT).show()
            return
        }
        val lista = Ajustes.favoritos(this)
        val existente = lista.firstOrNull { it.url == p.url }
        if (existente != null) {
            lista.remove(existente)
            Toast.makeText(this, "Favorito eliminado", Toast.LENGTH_SHORT).show()
        } else {
            lista.add(Favorito(if (p.titulo.isNotBlank()) p.titulo else legible(p.url), p.url))
            Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show()
        }
        Ajustes.guardarFavoritos(this, lista)
    }

    private fun compartir(p: Pestana) {
        if (p.url.isEmpty()) return
        val envio = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, p.url)
        }
        startActivity(Intent.createChooser(envio, getString(R.string.share_title)))
    }

    private fun abrirDescargas() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No hay una app para ver descargas", Toast.LENGTH_SHORT).show()
        }
    }

    private fun borrarDatos() {
        rt.storageController.clearData(StorageController.ClearFlags.ALL)
        Toast.makeText(this, R.string.datos_borrados, Toast.LENGTH_SHORT).show()
        actual?.let { if (!it.inicio) it.session.reload() }
    }

    // ---------- Descargas ----------

    private fun descargar(response: WebResponse) {
        val cuerpo = response.body ?: return
        val cabeceras = response.headers
        val tipo = cabeceras.entries
            .firstOrNull { it.key.equals("content-type", ignoreCase = true) }?.value
            ?.substringBefore(';')?.trim()
        val disposicion = cabeceras.entries
            .firstOrNull { it.key.equals("content-disposition", ignoreCase = true) }?.value
        val mime = if (tipo.isNullOrBlank()) "application/octet-stream" else tipo
        val nombre = URLUtil.guessFileName(response.uri, disposicion, mime)

        Thread {
            try {
                val valores = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, nombre)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = contentResolver
                val destino = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
                    ?: throw IllegalStateException("No se pudo crear el archivo")
                resolver.openOutputStream(destino)?.use { salida ->
                    cuerpo.use { entrada -> entrada.copyTo(salida) }
                } ?: throw IllegalStateException("No se pudo escribir el archivo")
                valores.clear()
                valores.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(destino, valores, null, null)
                runOnUiThread {
                    Toast.makeText(this, "Descargado: $nombre", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Error al descargar el archivo", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- Pantalla completa (videos) ----------

    private fun modoPantallaCompleta(activar: Boolean) {
        pantallaCompleta = activar
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (activar) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
        val visibilidad = if (activar) View.GONE else View.VISIBLE
        topBar.visibility = visibilidad
        bottomBar.visibility = visibilidad
        bottomLine.visibility = visibilidad
        progressBar.visibility = if (activar) View.GONE else progressBar.visibility
    }

    // ---------- Interfaz ----------

    private fun actualizarUI() {
        val p = actual ?: return
        val pal = paleta(p.privada)

        inicioView.visibility = if (p.inicio) View.VISIBLE else View.GONE
        if (!urlField.hasFocus()) urlField.setText(if (p.inicio) "" else legible(p.url))

        if (!pantallaCompleta) {
            progressBar.visibility = if (p.cargando && !p.inicio) View.VISIBLE else View.INVISIBLE
        }

        val puedeVolver = p.puedeAtras || (p.inicio && p.url.isNotEmpty())
        btnBack.isEnabled = puedeVolver
        btnBack.alpha = if (puedeVolver) 1f else 0.35f
        btnForward.isEnabled = p.puedeAdelante
        btnForward.alpha = if (p.puedeAdelante) 1f else 0.35f

        btnReload.setImageResource(if (p.cargando) R.drawable.ic_close else R.drawable.ic_refresh)
        btnReload.alpha = if (p.inicio) 0.35f else 1f

        tabsConteo.text = pestanas.size.toString()
        btnShield.imageTintList =
            ColorStateList.valueOf(if (Ajustes.proteccionActiva(this)) pal.brand else pal.muted)
        btnReload.imageTintList = ColorStateList.valueOf(pal.ink)
    }

    private fun paleta(privada: Boolean): Paleta {
        if (privada) {
            return Paleta(
                Color.parseColor("#1E1530"),
                Color.parseColor("#33274D"),
                Color.parseColor("#F1EAFB"),
                Color.parseColor("#A796C4"),
                Color.parseColor("#3A2D57"),
                Color.parseColor("#B79CFF")
            )
        }
        return Paleta(
            ContextCompat.getColor(this, R.color.surface),
            ContextCompat.getColor(this, R.color.field),
            ContextCompat.getColor(this, R.color.ink),
            ContextCompat.getColor(this, R.color.icon_muted),
            ContextCompat.getColor(this, R.color.line),
            ContextCompat.getColor(this, R.color.brand)
        )
    }

    private fun esOscuro(privada: Boolean): Boolean {
        if (privada) return true
        val modo = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return modo == Configuration.UI_MODE_NIGHT_YES
    }

    private fun aplicarColores() {
        val privada = actual?.privada == true
        val pal = paleta(privada)

        raiz.setBackgroundColor(pal.surface)
        principal.setBackgroundColor(pal.surface)
        topBar.setBackgroundColor(pal.surface)
        bottomBar.setBackgroundColor(pal.surface)
        bottomLine.setBackgroundColor(pal.line)

        (urlField.background.mutate() as GradientDrawable).setColor(pal.field)
        urlField.setTextColor(pal.ink)
        urlField.setHintTextColor(pal.muted)
        progressBar.progressTintList = ColorStateList.valueOf(pal.brand)

        val tinte = ColorStateList.valueOf(pal.ink)
        btnBack.imageTintList = tinte
        btnForward.imageTintList = tinte
        btnHome.imageTintList = tinte
        btnMenu.imageTintList = tinte
        btnReload.imageTintList = tinte

        tabsConteo.setTextColor(pal.ink)
        tabsConteo.background = GradientDrawable().apply {
            cornerRadius = dp(7).toFloat()
            setStroke(dp(2), pal.ink)
            setColor(Color.TRANSPARENT)
        }

        window.statusBarColor = pal.surface
        window.navigationBarColor = pal.surface
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = !esOscuro(privada)
        c.isAppearanceLightNavigationBars = !esOscuro(privada)
    }

    // ---------- Página de inicio nativa ----------

    private fun renderInicio() {
        val p = actual ?: return
        val pal = paleta(p.privada)
        inicioView.setBackgroundColor(pal.surface)
        inicioContenido.removeAllViews()
        inicioContenido.setPadding(dp(20), dp(40), dp(20), dp(24))

        val icono = ImageView(this).apply {
            setImageResource(if (p.privada) R.drawable.ic_incognito else R.drawable.ic_shield)
            imageTintList = ColorStateList.valueOf(pal.brand)
        }
        inicioContenido.addView(
            icono,
            LinearLayout.LayoutParams(dp(56), dp(56)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        )

        inicioContenido.addView(
            textoCentrado(
                if (p.privada) "Pestaña de incógnito" else "Limpio",
                26f, pal.ink, true
            ).apply { setPadding(0, dp(12), 0, dp(6)) }
        )
        inicioContenido.addView(
            textoCentrado(
                if (p.privada) {
                    "Limpio no guardará tu historial, cookies ni datos de sitios al cerrar estas " +
                        "pestañas. Tu proveedor de internet y los sitios que visites aún pueden " +
                        "ver tu actividad."
                } else {
                    "Navega sin anuncios ni rastreadores"
                },
                14f, pal.muted, false
            ).apply { setPadding(dp(8), 0, dp(8), dp(28)) }
        )

        val favoritos = Ajustes.favoritos(this)
        if (favoritos.isEmpty()) return

        inicioContenido.addView(
            TextView(this).apply {
                text = "Favoritos"
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(pal.muted)
                setPadding(dp(4), 0, 0, dp(8))
            }
        )

        for (fila in favoritos.chunked(4)) {
            val filaView = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (f in fila) {
                filaView.addView(crearTile(f, pal), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            for (i in fila.size until 4) {
                filaView.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            inicioContenido.addView(filaView)
        }
    }

    private fun textoCentrado(texto: String, tamano: Float, color: Int, negrita: Boolean) =
        TextView(this).apply {
            text = texto
            textSize = tamano
            gravity = Gravity.CENTER
            setTextColor(color)
            if (negrita) typeface = Typeface.DEFAULT_BOLD
        }

    private fun crearTile(f: Favorito, pal: Paleta): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        val circulo = TextView(this).apply {
            text = f.titulo.trim().take(1).uppercase()
            gravity = Gravity.CENTER
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(colorDe(f.url))
            }
        }
        col.addView(circulo, LinearLayout.LayoutParams(dp(52), dp(52)))
        col.addView(
            TextView(this).apply {
                text = f.titulo
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                textSize = 12f
                gravity = Gravity.CENTER_HORIZONTAL
                setTextColor(pal.ink)
                setPadding(0, dp(6), 0, 0)
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        col.setOnClickListener { cargar(f.url) }
        col.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle(f.titulo)
                .setMessage("¿Quitar de favoritos?")
                .setPositiveButton("Quitar") { _, _ ->
                    val lista = Ajustes.favoritos(this)
                    lista.removeAll { it.url == f.url }
                    Ajustes.guardarFavoritos(this, lista)
                    renderInicio()
                }
                .setNegativeButton("Cancelar", null)
                .show()
            true
        }
        return col
    }

    private fun colorDe(url: String): Int {
        val colores = intArrayOf(
            Color.parseColor("#0B6E5C"), Color.parseColor("#C2410C"),
            Color.parseColor("#1D4ED8"), Color.parseColor("#7E22CE"),
            Color.parseColor("#BE123C"), Color.parseColor("#4D7C0F")
        )
        return colores[(url.hashCode() and 0x7fffffff) % colores.size]
    }

    // ---------- Utilidades ----------

    private fun cargar(entrada: String) {
        val p = actual ?: return
        if (entrada.isBlank()) return
        p.inicio = false
        p.session.loadUri(normalizar(entrada))
        actualizarUI()
    }

    private fun normalizar(texto: String): String {
        val t = texto.trim()
        if (t.startsWith("http://") || t.startsWith("https://") ||
            t.startsWith("about:") || t.startsWith("file://")
        ) return t
        val pareceDominio = !t.contains(' ') && t.contains('.')
        return if (pareceDominio) "https://$t" else Ajustes.motor(this).url + Uri.encode(t)
    }

    private fun legible(url: String): String =
        url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

    private fun ocultarTeclado() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlField.windowToken, 0)
        urlField.clearFocus()
        geckoView.requestFocus()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val UBO_ID = "uBlock0@raymondhill.net"
        private const val UBO_URL =
            "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi"

        private const val MENU_NUEVA = 1
        private const val MENU_INCOGNITO = 2
        private const val MENU_FAVORITO = 3
        private const val MENU_ESCRITORIO = 4
        private const val MENU_COMPARTIR = 5
        private const val MENU_DESCARGAS = 6
        private const val MENU_AJUSTES = 7

        private var runtime: GeckoRuntime? = null
    }
}
