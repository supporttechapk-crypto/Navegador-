package com.limpio.browser

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.StorageController

class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var session: GeckoSession
    private lateinit var urlField: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnShield: ImageButton
    private lateinit var btnMenu: ImageButton

    private var canGoBack = false
    private var canGoForward = false
    private var loading = false
    private var protectionOn = true
    private var currentUrl = HOME_URL

    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        geckoView = findViewById(R.id.geckoView)
        urlField = findViewById(R.id.urlField)
        progressBar = findViewById(R.id.progressBar)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnReload = findViewById(R.id.btnReload)
        btnHome = findViewById(R.id.btnHome)
        btnShield = findViewById(R.id.btnShield)
        btnMenu = findViewById(R.id.btnMenu)

        protectionOn = prefs.getBoolean(KEY_PROTECTION, true)

        val rt = obtenerRuntime()
        aplicarProteccion()

        session = GeckoSession()
        session.progressDelegate = crearProgressDelegate()
        session.navigationDelegate = crearNavigationDelegate()
        session.open(rt)
        geckoView.setSession(session)

        configurarControles()
        actualizarBotones()

        val inicial = intent?.data?.toString()
        session.loadUri(if (inicial.isNullOrBlank()) HOME_URL else inicial)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val destino = intent.data?.toString()
        if (!destino.isNullOrBlank()) cargar(destino)
    }

    override fun onDestroy() {
        session.close()
        super.onDestroy()
    }

    // ---------- Motor y privacidad ----------

    private fun obtenerRuntime(): GeckoRuntime {
        val existente = runtime
        if (existente != null) return existente
        val ajustes = GeckoRuntimeSettings.Builder()
            .allowInsecureConnections(GeckoRuntimeSettings.HTTPS_ONLY)
            .remoteDebuggingEnabled(false)
            .build()
        val nuevo = GeckoRuntime.create(applicationContext, ajustes)
        runtime = nuevo
        return nuevo
    }

    private fun aplicarProteccion() {
        val bloqueo = obtenerRuntime().settings.contentBlocking
        if (protectionOn) {
            bloqueo.setAntiTracking(ContentBlocking.AntiTracking.STRICT)
            bloqueo.setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
            bloqueo.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
        } else {
            bloqueo.setAntiTracking(ContentBlocking.AntiTracking.NONE)
            bloqueo.setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_ALL)
            bloqueo.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.NONE)
        }
    }

    // ---------- Delegados de la sesión ----------

    private fun crearProgressDelegate() = object : GeckoSession.ProgressDelegate {
        override fun onPageStart(s: GeckoSession, url: String) {
            loading = true
            progressBar.progress = 0
            progressBar.visibility = View.VISIBLE
            actualizarBotones()
        }

        override fun onPageStop(s: GeckoSession, success: Boolean) {
            loading = false
            progressBar.visibility = View.INVISIBLE
            actualizarBotones()
        }

        override fun onProgressChange(s: GeckoSession, progress: Int) {
            progressBar.progress = progress
        }
    }

    private fun crearNavigationDelegate() = object : GeckoSession.NavigationDelegate {
        override fun onLocationChange(
            s: GeckoSession,
            url: String?,
            perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
            hasUserGesture: Boolean
        ) {
            if (url == null) return
            currentUrl = url
            if (!urlField.hasFocus()) urlField.setText(legible(url))
        }

        override fun onCanGoBack(s: GeckoSession, canGoBack: Boolean) {
            this@MainActivity.canGoBack = canGoBack
            actualizarBotones()
        }

        override fun onCanGoForward(s: GeckoSession, canGoForward: Boolean) {
            this@MainActivity.canGoForward = canGoForward
            actualizarBotones()
        }

        override fun onLoadRequest(
            s: GeckoSession,
            request: GeckoSession.NavigationDelegate.LoadRequest
        ): GeckoResult<AllowOrDeny>? {
            val destino = request.uri
            val externo = destino.startsWith("mailto:") || destino.startsWith("tel:") ||
                destino.startsWith("sms:") || destino.startsWith("geo:")
            if (externo) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(destino)))
                } catch (e: ActivityNotFoundException) {
                    // No hay una aplicación que lo abra.
                }
                return GeckoResult.fromValue(AllowOrDeny.DENY)
            }
            return null
        }

        override fun onNewSession(s: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
            // Los enlaces que piden una ventana nueva se abren en la misma pestaña.
            session.loadUri(uri)
            return null
        }
    }

    // ---------- Controles ----------

    private fun configurarControles() {
        urlField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                cargar(urlField.text.toString())
                ocultarTeclado()
                true
            } else {
                false
            }
        }
        urlField.setOnFocusChangeListener { _, tieneFoco ->
            if (tieneFoco) {
                urlField.setText(currentUrl)
                urlField.post { urlField.selectAll() }
            } else {
                urlField.setText(legible(currentUrl))
            }
        }

        btnBack.setOnClickListener { if (canGoBack) session.goBack() }
        btnForward.setOnClickListener { if (canGoForward) session.goForward() }
        btnReload.setOnClickListener { if (loading) session.stop() else session.reload() }
        btnHome.setOnClickListener { cargar(HOME_URL) }

        btnShield.setOnClickListener {
            protectionOn = !protectionOn
            prefs.edit().putBoolean(KEY_PROTECTION, protectionOn).apply()
            aplicarProteccion()
            actualizarBotones()
            session.reload()
            val mensaje = if (protectionOn) R.string.proteccion_on else R.string.proteccion_off
            Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener { mostrarMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (canGoBack) session.goBack() else finish()
            }
        })
    }

    private fun mostrarMenu() {
        val menu = PopupMenu(this, btnMenu)
        menu.menu.add(0, MENU_HOME, 0, getString(R.string.menu_home))
        menu.menu.add(0, MENU_SHARE, 1, getString(R.string.menu_share))
        menu.menu.add(0, MENU_CLEAR, 2, getString(R.string.menu_clear))
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                MENU_HOME -> cargar(HOME_URL)
                MENU_SHARE -> compartir()
                MENU_CLEAR -> borrarDatos()
            }
            true
        }
        menu.show()
    }

    private fun compartir() {
        val envio = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, currentUrl)
        }
        startActivity(Intent.createChooser(envio, getString(R.string.share_title)))
    }

    private fun borrarDatos() {
        obtenerRuntime().storageController.clearData(StorageController.ClearFlags.ALL)
        Toast.makeText(this, R.string.datos_borrados, Toast.LENGTH_SHORT).show()
        session.reload()
    }

    private fun actualizarBotones() {
        btnBack.isEnabled = canGoBack
        btnBack.alpha = if (canGoBack) 1f else 0.35f
        btnForward.isEnabled = canGoForward
        btnForward.alpha = if (canGoForward) 1f else 0.35f
        btnReload.setImageResource(if (loading) R.drawable.ic_close else R.drawable.ic_refresh)
        val color = if (protectionOn) R.color.brand else R.color.icon_muted
        btnShield.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
    }

    // ---------- Utilidades ----------

    private fun cargar(entrada: String) {
        session.loadUri(normalizar(entrada))
    }

    private fun normalizar(texto: String): String {
        val t = texto.trim()
        if (t.isEmpty()) return HOME_URL
        if (t.startsWith("http://") || t.startsWith("https://") ||
            t.startsWith("about:") || t.startsWith("file://")
        ) return t
        val pareceDominio = !t.contains(' ') && t.contains('.')
        return if (pareceDominio) "https://$t" else SEARCH_URL + Uri.encode(t)
    }

    private fun legible(url: String): String =
        url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

    private fun ocultarTeclado() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlField.windowToken, 0)
        urlField.clearFocus()
        geckoView.requestFocus()
    }

    companion object {
        private const val HOME_URL = "https://duckduckgo.com"
        private const val SEARCH_URL = "https://duckduckgo.com/?q="
        private const val PREFS = "limpio"
        private const val KEY_PROTECTION = "proteccion"
        private const val MENU_HOME = 1
        private const val MENU_SHARE = 2
        private const val MENU_CLEAR = 3

        private var runtime: GeckoRuntime? = null
    }
}
